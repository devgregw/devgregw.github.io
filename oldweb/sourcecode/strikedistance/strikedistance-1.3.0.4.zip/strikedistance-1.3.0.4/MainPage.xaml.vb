﻿Imports System
Imports System.Threading
Imports System.Windows.Controls
Imports Microsoft.Phone.Controls
Imports Microsoft.Phone.Shell
Imports System.IO.IsolatedStorage

' FIX FILE LOADER

Partial Public Class MainPage
    Inherits PhoneApplicationPage
    Private nextPage As Uri
    Private Sub setNextPage(ByVal address As Uri)
        nextPage = address
    End Sub
    Private d As Integer
    Private WithEvents appBar As ApplicationBar
    Private WithEvents calcBtn As ApplicationBarIconButton
    Private WithEvents clearBtn As ApplicationBarIconButton
    Private WithEvents aboutBtn As ApplicationBarMenuItem
    Private tempSelectAll As Boolean = True
    Private timeSelectAll As Boolean = True
    Public Sub New()
        InitializeComponent()
        LayoutRoot.Opacity = 0.0
        Using a As New SettingsManager(Of Integer)
            d = a.Read("DecimalPlaces") : End Using
    End Sub
    Private Sub calculate(sender As Object, e As EventArgs) Handles calcBtn.Click
        tempBox_LostFocus(sender, Nothing)
        timeBox_LostFocus(sender, Nothing)
        Dim metricunit As String = "meters"
        Dim englishunit As String = "miles"
        Dim res As Double
        Dim time As Double = timeBox.Text
        Dim temp As Double = tempBox.Text
        Dim p1 As Double
        Dim p2 As Double
        If tempUnit.Text.ToLower() = "fahrenheit" Then
            temp = unitConverter.toCelsius(False, tempBox.Text)
        ElseIf tempUnit.Text.ToLower() = "kelvin" Then
            temp = unitConverter.toCelsius(True, tempBox.Text)
        End If
        p1 = (331.5 + 0.6 * temp)
        p2 = (p1) * (time)
        res = Math.Round(p2, d, MidpointRounding.AwayFromZero)
        If distUnit.Text.ToLower() = "miles" Then
            res = unitConverter.toMiles(res)
            If res = 1 Then : englishunit = "mile"
            Else : englishunit = "miles"
            End If
            If Not res.ToString().ToLower.Contains("e") Then
                MessageBox.Show(String.Format("The lightning struck approximately {0} {1} away.", res, englishunit), "Result", MessageBoxButton.OK)
            Else
                MessageBox.Show("An overflow error has occured.  This happens when when one of the input fields or result is so large, it is converted to scientific notation.  Try reducing the temperature or time fields.", "Error", MessageBoxButton.OK)
            End If
        ElseIf distUnit.Text.ToLower().Contains("meters") Then
            If res >= 1000 Then
                res = Math.Round(res / 1000, d, MidpointRounding.AwayFromZero)
                If res = 1 Then : metricunit = "kilometer"
                Else : metricunit = "kilometers"
                End If
            Else
                If res = 1 Then : metricunit = "meter"
                Else : metricunit = "meters"
                End If
            End If
            If Not res.ToString().ToLower().Contains("e") Then
                MessageBox.Show(String.Format("The lightning struck approximately {0} {1} away.", res, metricunit), "Result", MessageBoxButton.OK)
            Else
                MessageBox.Show("An overflow error has occured.  This happens when when one of the input fields or result is so large, it is converted to scientific notation.  Try reducing the temperature or time fields.", "Error", MessageBoxButton.OK)
            End If
        End If
    End Sub
    Private Sub changeSign(sender As Object, e As RoutedEventArgs) Handles signChange.Click
        tempBox.Text *= -1
    End Sub
    Private Sub clear(sender As Object, e As EventArgs) Handles clearBtn.Click
        tempBox.Text = "0"
        timeBox.Text = "0"
    End Sub
    Private Sub initialize(sender As Object, e As RoutedEventArgs) Handles calcpage.Loaded
        Using a As New SettingsManager(Of Boolean)
            Try
                If a.Read("FirstLoad") = True Then
                    NavigationService.Navigate(New Uri("/qs_intro.xaml", UriKind.Relative))
                End If
            Catch ex As Exception
                NavigationService.Navigate(New Uri("/qs_intro.xaml", UriKind.Relative))
            End Try
        End Using
        tempBox.Text = MemoryManager.GetTemperature()
        timeBox.Text = MemoryManager.GetTime()
        Try
            Using a As New SettingsManager(Of Boolean)
                If a.Read("FirstLoad:LoadDefaults") = True Then
                    Using b As New SettingsManager(Of Integer)
                        Dim Value As Integer = b.Read("DefaultTempUnit")
                        If Value = 0 Then : tempUnit.Text = "Fahrenheit"
                        ElseIf Value = 1 Then : tempUnit.Text = "Celsius"
                        ElseIf Value = 2 Then : tempUnit.Text = "Kelvin"
                        End If
                        Value = b.Read("DefaultDistUnit")
                        If Value = 0 Then : distUnit.Text = "miles"
                        ElseIf Value = 1 Then : distUnit.Text = "meters/kilometers"
                        End If
                        a.Save("FirstLoad:LoadDefaults", False)
                    End Using
                Else
                    Using b As New SettingsManager(Of Integer)
                        Dim Value As Integer = b.Read("TempUnit")
                        If Value = 0 Then : tempUnit.Text = "Fahrenheit"
                        ElseIf Value = 1 Then : tempUnit.Text = "Celsius"
                        ElseIf Value = 2 Then : tempUnit.Text = "Kelvin"
                        End If
                        Value = b.Read("DistUnit")
                        If Value = 0 Then : distUnit.Text = "miles"
                        ElseIf Value = 1 Then : distUnit.Text = "meters/kilometers"
                        End If
                    End Using
                End If
            End Using
            [in].Begin()
        Catch ex As Exception
            NavigationService.Navigate(New Uri("/qs_intro.xaml", UriKind.Relative))
        End Try
    End Sub
#Region "fieldFormattingMethods"
    Private Sub tempBox_Tap(sender As Object, e As System.Windows.Input.GestureEventArgs) Handles tempBox.Tap
        If tempSelectAll Then
            tempBox.SelectAll()
            tempSelectAll = False
        End If
    End Sub
    Private Sub timeBox_Tap(sender As Object, e As System.Windows.Input.GestureEventArgs) Handles timeBox.Tap
        If timeSelectAll Then
            timeBox.SelectAll()
            timeSelectAll = False
        End If
    End Sub
    Private Sub tempBox_LostFocus(sender As Object, e As RoutedEventArgs)
        If tempBox.Text = "" Then
            tempBox.Text = 0
        Else
            Dim x As Double = tempBox.Text
            tempBox.Text = Math.Round(x, d, MidpointRounding.AwayFromZero)
        End If
        tempSelectAll = True
    End Sub
    Private Sub timeBox_LostFocus(sender As Object, e As RoutedEventArgs)
        If timeBox.Text = "" Then
            timeBox.Text = 0
        Else
            Dim x As Double = timeBox.Text
            timeBox.Text = Math.Round(x, d, MidpointRounding.AwayFromZero)
        End If
        timeSelectAll = True
    End Sub
#End Region
#Region "animationMethods"
    Private Sub outFinished(sender As Object, e As EventArgs) Handles [out].Completed
        calcpage.NavigationService.Navigate(nextPage)
    End Sub
    Private Sub inFinished(sender As Object, e As EventArgs) Handles [in].Completed
        initializeAppBar()
    End Sub
#End Region
#Region "navigationMethods"
    Private Sub editUnits(sender As Object, e As RoutedEventArgs) Handles editBtn.Click
        nullify()
        MemoryManager.SetTemperature(tempBox.Text)
        MemoryManager.SetTime(timeBox.Text)
        Using a As New SettingsManager(Of Integer)
            Dim t As Integer
            Dim d As Integer
            If tempUnit.Text.ToLower() = "fahrenheit" Then
                t = 0
            ElseIf tempUnit.Text.ToLower() = "celsius" Then
                t = 1
            ElseIf tempUnit.Text.ToLower() = "kelvin" Then
                t = 2
            End If
            If distUnit.Text.ToLower() = "miles" Then
                d = 0
            ElseIf distUnit.Text.ToLower() = "meters/kilometers" Then
                d = 1
            End If
            a.Save("TempUnit", t)
            a.Save("DistUnit", d)
        End Using
        setNextPage(New Uri("/units.xaml", UriKind.Relative))
        Me.ApplicationBar = Nothing
        [out].Begin()
    End Sub
    Private Sub stopwatchBtn_Click(sender As Object, e As RoutedEventArgs) Handles stopwatchBtn.Click
        nullify()
        MemoryManager.SetTemperature(tempBox.Text)
        MemoryManager.SetTime(timeBox.Text)
        Using a As New SettingsManager(Of Integer)
            Dim t As Integer
            Dim d As Integer
            If tempUnit.Text.ToLower() = "fahrenheit" Then
                t = 0
            ElseIf tempUnit.Text.ToLower() = "celsius" Then
                t = 1
            ElseIf tempUnit.Text.ToLower() = "kelvin" Then
                t = 2
            End If
            If distUnit.Text.ToLower() = "miles" Then
                d = 0
            ElseIf distUnit.Text.ToLower() = "meters/kilometers" Then
                d = 1
            End If
            a.Save("TempUnit", t)
            a.Save("DistUnit", d)
        End Using
        setNextPage(New Uri("/stopwatch.xaml", UriKind.Relative))
        Me.ApplicationBar = Nothing
        [out].Begin()
    End Sub
    Private Sub showAbout(sender As Object, e As EventArgs) Handles aboutBtn.Click
        nullify()
        MemoryManager.SetTemperature(tempBox.Text)
        MemoryManager.SetTime(timeBox.Text)
        Using a As New SettingsManager(Of Integer)
            Dim t As Integer
            Dim d As Integer
            If tempUnit.Text.ToLower() = "fahrenheit" Then
                t = 0
            ElseIf tempUnit.Text.ToLower() = "celsius" Then
                t = 1
            ElseIf tempUnit.Text.ToLower() = "kelvin" Then
                t = 2
            End If
            If distUnit.Text.ToLower() = "miles" Then
                d = 0
            ElseIf distUnit.Text.ToLower() = "meters/kilometers" Then
                d = 1
            End If
            a.Save("TempUnit", t)
            a.Save("DistUnit", d)
        End Using
        setNextPage(New Uri("/about.xaml", UriKind.Relative))
        Me.ApplicationBar = Nothing
        [out].Begin()
    End Sub
#End Region
#Region "applicationBarStatusMethods"
    Private Sub nullify()
        Me.ApplicationBar = Nothing
        appBar = Nothing
        calcBtn = Nothing
        clearBtn = Nothing
        aboutBtn = Nothing
    End Sub
    Private Sub initializeAppBar()
        appBar = New ApplicationBar()
        calcBtn = New ApplicationBarIconButton(New Uri("/Assets/AppBar/check.png", UriKind.Relative))
        clearBtn = New ApplicationBarIconButton(New Uri("/Assets/AppBar/cancel.png", UriKind.Relative))
        aboutBtn = New ApplicationBarMenuItem("about...")
        calcBtn.Text = "calculate"
        clearBtn.Text = "start over"
        appBar.MenuItems.Add(aboutBtn)
        appBar.Buttons.Add(calcBtn)
        appBar.Buttons.Add(clearBtn)
        appBar.BackgroundColor = Color.FromArgb(255, 200, 200, 0)
        Me.ApplicationBar = appBar
    End Sub
#End Region
End Class
