﻿Module unitConverter
    Dim d As Integer

    Function toMiles(ByVal meters As Double) As Double
        Using a As New SettingsManager(Of Integer)
            d = a.Read("DecimalPlaces") : End Using
        Return Math.Round(meters * 0.00062137, d, MidpointRounding.AwayFromZero)
    End Function
    Function toCelsius(ByVal Kelvin As Boolean, ByVal Temp As Double) As Double
        Using a As New SettingsManager(Of Integer)
            d = a.Read("DecimalPlaces") : End Using
        If Kelvin = True Then
            Return Math.Round(Temp - 273.15, d, MidpointRounding.AwayFromZero)
        Else
            Return Math.Round((Temp - 32) * 5 / 9, d, MidpointRounding.AwayFromZero)
        End If
    End Function
End Module
