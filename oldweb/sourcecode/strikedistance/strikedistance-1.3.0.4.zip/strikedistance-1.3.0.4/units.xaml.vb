﻿Partial Public Class units
    Inherits PhoneApplicationPage
    Private nextPage As Uri
    Private Sub setNextPage(ByVal page As Uri)
        nextPage = page
    End Sub
    Private WithEvents appBar As ApplicationBar
    Private WithEvents doneBtn As ApplicationBarIconButton
    Private WithEvents cancelBtn As ApplicationBarIconButton
    Private WithEvents restoreBtn As ApplicationBarIconButton
    Private WithEvents editBtn As ApplicationBarMenuItem
    Private temp As Integer = 0
    Private dist As Integer = 0
    Public Sub New()
        InitializeComponent()
        LayoutRoot.Opacity = 0.0
    End Sub
    Private Sub loadCurrentSettings(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        initializeAppBar()
        [in].Begin()
        Using a As New SettingsManager(Of Integer)
            temp = a.Read("TempUnit")
            tempUnit.SelectedIndex = temp
            dist = a.Read("DistUnit")
            distUnit.SelectedIndex = dist
        End Using
    End Sub
    Private Sub editDefaults(sender As Object, e As EventArgs) Handles editBtn.Click
        setNextPage(New Uri("/qs_units.xaml", UriKind.Relative))
        Me.ApplicationBar = Nothing
        [out].Begin()
    End Sub
    Private Sub restoreDefaults(sender As Object, e As EventArgs) Handles restoreBtn.Click
        Try
            Using a As New SettingsManager(Of Integer)
                a.Save("TempUnit", a.Read("DefaultTempUnit"))
                a.Save("DistUnit", a.Read("DefaultDistUnit"))
            End Using
            setNextPage(New Uri("/MainPage.xaml", UriKind.Relative))
            nullify()
            [out].Begin()
        Catch ex As Exception
            MessageBox.Show(String.Format("An error occured while performing the operation.{0}{0}{1}", Environment.NewLine, ex.Message), "Error", MessageBoxButton.OK)
        End Try
    End Sub
    Private Sub saveSettings(sender As Object, e As EventArgs) Handles doneBtn.Click
        Using a As New SettingsManager(Of Integer)
            a.Save("TempUnit", temp)
            a.Save("DistUnit", dist)
        End Using
        setNextPage(New Uri("/MainPage.xaml", UriKind.Relative))
        nullify()
        [out].Begin()
    End Sub
    Private Sub goBack(sender As Object, e As EventArgs) Handles cancelBtn.Click
        setNextPage(New Uri("/MainPage.xaml", UriKind.Relative))
        nullify()
        [out].Begin()
    End Sub
    Private Sub tempChange(sender As Object, e As RoutedEventArgs) Handles tempUnit.SelectionChanged
        temp = tempUnit.SelectedIndex
    End Sub
    Private Sub distChange(sender As Object, e As RoutedEventArgs) Handles distUnit.SelectionChanged
        dist = distUnit.SelectedIndex
    End Sub
    Private Sub outFinished(sender As Object, e As EventArgs) Handles [out].Completed
        NavigationService.Navigate(nextPage)
    End Sub
    Private Sub inFinished(sender As Object, e As EventArgs) Handles [in].Completed
        showAppBar()
    End Sub
#Region "applicationBarStatusMethods"
    Private Sub nullify()
        Me.ApplicationBar = Nothing
        appBar = Nothing
        doneBtn = Nothing
        cancelBtn = Nothing
        restoreBtn = Nothing
        editBtn = Nothing
    End Sub
    Private Sub initializeAppBar()
        appBar = New ApplicationBar()
        doneBtn = New ApplicationBarIconButton(New Uri("/Assets/AppBar/save.png", UriKind.Relative))
        cancelBtn = New ApplicationBarIconButton(New Uri("/Assets/AppBar/cancel.png", UriKind.Relative))
        restoreBtn = New ApplicationBarIconButton(New Uri("/Assets/AppBar/photo.fix.png", UriKind.Relative))
        editBtn = New ApplicationBarMenuItem("edit defaults...")
        doneBtn.Text = "save"
        cancelBtn.Text = "cancel"
        restoreBtn.Text = "defaults"
        appBar.Buttons.Add(doneBtn)
        appBar.Buttons.Add(cancelBtn)
        appBar.Buttons.Add(restoreBtn)
        appBar.MenuItems.Add(editBtn)
        appBar.Opacity = 0.0
        appBar.IsVisible = False
        appBar.BackgroundColor = Color.FromArgb(255, 200, 200, 0)
        Me.ApplicationBar = appBar
    End Sub
    Private Sub showAppBar()
        For i As Double = 0.0 To 1.0 Step 0.1
            appBar.Opacity = i
        Next
        appBar.IsVisible = True
    End Sub
#End Region
End Class
