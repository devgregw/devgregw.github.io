﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Resources

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes
<Assembly: AssemblyTitle("StrikeDistance")> 
<Assembly: AssemblyDescription("Calculator that determines the distance between you and a lightning strike.")> 
<Assembly: AssemblyConfiguration("")> 
<Assembly: AssemblyCompany("Blue Hex Apps")> 
<Assembly: AssemblyProduct("StrikeDistance")> 
<Assembly: AssemblyCopyright("Copyright © PIXL Apps 2014")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")> 

' Setting ComVisible to false makes the types in this assembly not visible 
' to COM components.  If you need to access a type in this assembly from 
' COM, set the ComVisible attribute to true on that type.
<assembly: ComVisible(false)>

' The following GUID is for the ID of the typelib if this project is exposed to COM
<assembly: Guid("038d25ba-93b2-4edd-9dda-d3c397798d09")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Revision and Build Numbers 
' by using the '*' as shown below:
<Assembly: AssemblyVersion("1.3.0.4")> 
<Assembly: AssemblyFileVersion("1.3.0.4")> 
<assembly: NeutralResourcesLanguageAttribute("en-US")>
