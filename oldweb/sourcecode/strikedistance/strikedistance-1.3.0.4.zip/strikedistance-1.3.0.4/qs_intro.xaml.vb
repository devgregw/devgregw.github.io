﻿Imports System.IO.IsolatedStorage

Partial Public Class firstLoad1
    Inherits PhoneApplicationPage
    Private nextPage As Uri
    Private Sub setNextPage(ByVal page As Uri)
        nextPage = page
    End Sub
    Public Sub New()
        InitializeComponent()
        Using x As New SettingsManager(Of String)
            x.InitializeAll()
        End Using
        LayoutRoot.Opacity = 0.0
    End Sub
    Private Sub pageLoad(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        MemoryManager.SetTemperature()
        MemoryManager.SetTime()
        [in].Begin()
    End Sub
    Private Sub nextBtn_Click(sender As Object, e As RoutedEventArgs) Handles nextBtn.Click
        setNextPage(New Uri("/qs_units.xaml", UriKind.Relative))
        [out].Begin()
    End Sub
    Private Sub outFinished(sender As Object, e As EventArgs) Handles [out].Completed
        NavigationService.Navigate(nextPage)
    End Sub
End Class
