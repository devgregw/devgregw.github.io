﻿Public Class MemoryManager

    Public Shared Temperature As Double = 0
    Public Shared Time As Double = 0

    Public Shared Function GetTemperature() As Double
        Return Temperature
    End Function

    Public Shared Function GetTime() As Double
        Return Time
    End Function

    Public Shared Sub SetTemperature(x As Double)
        Temperature = x
    End Sub
    Public Shared Sub SetTemperature()
        Temperature = 0
    End Sub

    Public Shared Sub SetTime(x As Double)
        Time = x
    End Sub
    Public Shared Sub SetTime()
        Time = 0
    End Sub
End Class
