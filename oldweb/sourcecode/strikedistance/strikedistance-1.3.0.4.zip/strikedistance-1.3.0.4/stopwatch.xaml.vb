﻿Imports System
Imports System.Windows.Media.Animation
Imports System.Windows.Threading

Partial Public Class stopwatch
    Inherits PhoneApplicationPage
    Private nextPage As Uri
    Private Sub setNextPage(ByVal page As Uri)
        nextPage = page
    End Sub
    Private d As Integer
    Private isCounting As Boolean = False
    Private WithEvents appBar As ApplicationBar
    Private WithEvents backBtn As ApplicationBarIconButton
    Private WithEvents ctrlBtn As ApplicationBarIconButton
    Private WithEvents insertBtn As ApplicationBarIconButton
    Private WithEvents resetBtn As ApplicationBarMenuItem
    Private WithEvents stopwatch As New DispatcherTimer()
    Private rawElapsed As Double
    Private roundedTime As Double
    Public Sub New()
        InitializeComponent()
        LayoutRoot.Opacity = 0.0
        stopwatch.Interval = New TimeSpan(TimeSpan.TicksPerMillisecond)
        Using x As New SettingsManager(Of Integer)
            d = x.Read("DecimalPlaces")
        End Using
    End Sub
    Private Sub pageLoad(sender As Object, e As EventArgs) Handles stopwatchPage.Loaded
        [in].Begin()
    End Sub
    Private Sub goBack(sender As Object, e As EventArgs) Handles backBtn.Click
        setNextPage(New Uri("/MainPage.xaml", UriKind.Relative))
        nullify()
        [out].Begin()
    End Sub
    Private Sub resetStopwatch(sender As Object, e As EventArgs) Handles resetBtn.Click
        insertBtn.IsEnabled = False
        timeLabel.Text = "tap the play button"
        rawElapsed = 0
        roundedTime = 0
    End Sub
    Private Sub stopwatchControl(sender As Object, e As EventArgs) Handles ctrlBtn.Click
        If isCounting = True Then
            isCounting = False
            backBtn.IsEnabled = True
            resetBtn.IsEnabled = True
            insertBtn.IsEnabled = True
            ctrlBtn.Text = "start"
            ctrlBtn.IconUri = New Uri("/Assets/AppBar/transport.play.png", UriKind.Relative)
            stopwatch.Stop()
        ElseIf isCounting = False Then
            isCounting = True
            backBtn.IsEnabled = False
            resetBtn.IsEnabled = False
            insertBtn.IsEnabled = False
            ctrlBtn.Text = "stop"
            ctrlBtn.IconUri = New Uri("/Assets/AppBar/stop.png", UriKind.Relative)
            stopwatch.Start()
        End If
    End Sub
    Private Sub insertTime(sender As Object, e As EventArgs) Handles insertBtn.Click
        MemoryManager.SetTime(roundedTime)
        setNextPage(New Uri("/MainPage.xaml", UriKind.Relative))
        nullify()
        [out].Begin()
    End Sub
    Private Sub timerTick(sender As Object, e As EventArgs) Handles stopwatch.Tick
        rawElapsed += 1
        roundedTime = Math.Round(rawElapsed * 0.016, _
                                  d, _
                                  MidpointRounding.AwayFromZero) 'Perfected; do not edit
        timeLabel.Text = roundedTime
    End Sub
    Private Sub outFinished(sender As Object, e As EventArgs) Handles [out].Completed
        NavigationService.Navigate(nextPage)
    End Sub
    Private Sub inFinished(sender As Object, e As EventArgs) Handles [in].Completed
        initializeAppBar()
    End Sub
#Region "applicationBarStatusMethods"
    Private Sub nullify()
        Me.ApplicationBar = Nothing
        appBar = Nothing
        backBtn = Nothing
        ctrlBtn = Nothing
        insertBtn = Nothing
        resetBtn = Nothing
    End Sub
    Private Sub initializeAppBar()
        appBar = New ApplicationBar()
        backBtn = New ApplicationBarIconButton(New Uri("/Assets/AppBar/back.png", UriKind.Relative))
        ctrlBtn = New ApplicationBarIconButton(New Uri("/Assets/AppBar/transport.play.png", UriKind.Relative))
        insertBtn = New ApplicationBarIconButton(New Uri("/Assets/AppBar/check.png", UriKind.Relative))
        resetBtn = New ApplicationBarMenuItem("reset")
        backBtn.Text = "back"
        ctrlBtn.Text = "start"
        insertBtn.Text = "insert"
        insertBtn.IsEnabled = False
        appBar.Buttons.Add(backBtn)
        appBar.Buttons.Add(ctrlBtn)
        appBar.Buttons.Add(insertBtn)
        appBar.MenuItems.Add(resetBtn)
        appBar.Opacity = 1.0
        appBar.BackgroundColor = Color.FromArgb(255, 200, 200, 0)
        Me.ApplicationBar = appBar
    End Sub
#End Region
End Class
