﻿Partial Public Class qs_units
    Inherits PhoneApplicationPage
    Private nextPage As Uri
    Private Sub setNextPage(ByVal page As Uri)
        nextPage = page
    End Sub
    Public Sub New()
        InitializeComponent()
        LayoutRoot.Opacity = 0.0
    End Sub
    Private Sub pageLoad(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        Using a As New SettingsManager(Of Boolean)
            Using b As New SettingsManager(Of Integer)
                If a.Read("FirstLoad") = False Then
                    tempUnit.SelectedIndex = b.Read("TempUnit")
                    distUnit.SelectedIndex = b.Read("DistUnit")
                End If
            End Using
        End Using
        [in].Begin()
    End Sub
    Private Sub finishBtn_Click(sender As Object, e As RoutedEventArgs) Handles finishBtn.Click
        Dim T, D As Integer
        If tempUnit.SelectedItem.Equals(F) Then
            T = 0
        ElseIf tempUnit.SelectedItem.Equals(C) Then
            T = 1
        ElseIf tempUnit.SelectedItem.Equals(K) Then
            T = 2
        End If
        If distUnit.SelectedItem.Equals(Mi) Then
            D = 0
        ElseIf distUnit.SelectedItem.Equals([Me]) Then
            D = 1
        End If
        Using a As New SettingsManager(Of Integer)
            a.Save("DefaultTempUnit", T)
            a.Save("DefaultDistUnit", D)
        End Using
        Using b As New SettingsManager(Of Boolean)
            b.Save("FirstLoad", False)
            b.Save("FirstLoad:LoadDefaults", True)
        End Using
        setNextPage(New Uri("/MainPage.xaml", UriKind.Relative))
        [out].Begin()
    End Sub
    Private Sub outFinished(sender As Object, e As EventArgs) Handles [out].Completed
        NavigationService.Navigate(nextPage)
    End Sub
End Class
