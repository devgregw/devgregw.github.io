﻿Imports System.IO.IsolatedStorage

Public Class SettingsManager(Of X As IComparable)
    Implements IDisposable

    Public Settings As IsolatedStorageSettings = IsolatedStorageSettings.ApplicationSettings

    Public Sub Save(Key As String, Content As X)
        Try
            Settings(Key) = Content
        Catch ex As KeyNotFoundException
            If Key.Contains("Unit") Or Key = "DecimalPlaces" Then
                Settings.Add(Key, 0)
            ElseIf Key = "DecimalPlaces" Then
                Settings.Add("DecimalPlaces", 2)
            ElseIf Key.Contains("FirstLoad") Then
                Settings.Add(Key, True)
            ElseIf Key.Contains("Verbose") Then
                Settings.Add(Key, False)
            Else
                Throw ex
            End If
        End Try
    End Sub

    Public Function Read(Key As String) As X
        Try
            Return Settings(Key)
        Catch ex As KeyNotFoundException
            If Key.Contains("Unit") Then
                Settings.Add(Key, 0)
            ElseIf Key = "DecimalPlaces" Then
                Settings.Add("DecimalPlaces", 2)
            ElseIf Key.Contains("FirstLoad") Then
                Settings.Add(Key, True)
            ElseIf Key.Contains("Verbose") Then
                Settings.Add(Key, False)
            Else
                Throw ex
            End If
        End Try
    End Function

    Public Sub InitializeAll()
        Settings.Clear()
        Settings.Add("TempUnit", 0)
        Settings.Add("DistUnit", 0)
        Settings.Add("DefaultTempUnit", 0)
        Settings.Add("DefaultDistUnit", 0)
        Settings.Add("Verbose", False)
        Settings.Add("Verbose:UnitDetails", False)
        Settings.Add("Verbose:ConversionLogic", False)
        Settings.Add("Verbose:CalculationLogic", False)
        Settings.Add("DecimalPlaces", 2)
        Settings.Add("FirstLoad", True)
        Settings.Add("FirstLoad:LoadDefaults", True)
    End Sub

#Region "IDisposable Support"
    Private disposedValue As Boolean
    Protected Overridable Sub Dispose(disposing As Boolean)
        If Not Me.disposedValue Then
            If disposing Then
            End If
        End If
        Me.disposedValue = True
    End Sub
    Public Sub Dispose() Implements IDisposable.Dispose
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region

End Class
